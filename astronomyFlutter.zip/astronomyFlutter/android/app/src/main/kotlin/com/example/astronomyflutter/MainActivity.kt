package com.example.astronomyflutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
